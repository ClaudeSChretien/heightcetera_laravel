var markersInfos = [{
        name: 'South-Bank',
        Position: { lat: -27.48034, lng: 153.02049 },
        id: 1,
        imgSrc: 'southBank.jpg',
        Photographer: "CSC",
        rating: 5,
        date: new Date(2019, 6, 6),
        eventType: "restaurant",
        url: '/img/icon/restaurant.png',
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut consectetur ante eget."
    },

    {
        name: 'Brisbane-Airport',
        Position: { lat: -27.3833318, lng: 153.11749953 },
        id: 2,
        imgSrc: 'sdemo-image-01.jpg',
        Photographer: "CSC",
        rating: 5,
        date: new Date(2019, 6, 25),
        eventType: "activity",
        url: '/img/icon/activity.png',
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut consectetur ante eget."
    },

    {
        name: 'mt-coottha',
        Position: { lat: -27.4806, lng: 152.9541 },
        id: 3,
        imgSrc: 'mt-coottha.jpg',
        Photographer: "CSC",
        rating: 5,
        date: new Date(2019, 6, 20),
        eventType: "personal",
        url: '/img/icon/personal.png',
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut consectetur ante eget."
    }
]

/*

  Map hover

*/

/* Google Map */
// Initialize and add the map

var map;
var markers = [];
var markerCluster;

function initMap() {

    var mapOptions = {
        center: new google.maps.LatLng(-27.470125, 153.021072),
        zoom: 12,
        disableDefaultUI: true,
        fullscreenControl: false,
        streetViewControl: false

    };

    map = new google.maps.Map(document.getElementById("map"), mapOptions);

    addMarkers(markersInfos);
    markerCluster = new MarkerClusterer(map, markers, { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    google.maps.event.addListener(map, 'idle', function() {
        showVisibleMarkers();
    });
}

function addMarkers(markersInfos) {
    if (typeof variable !== 'undefined') {
        markerCluster.setMap(null);
    }

    for (var i = 0; i < markers.length; i++) {

        markers[i].setMap(null);
    }

    // Reset the markers array
    markers = [];
    var markerIcon = {
        scaledSize: new google.maps.Size(35, 35), // scaled size
        origin: new google.maps.Point(0, 0), // origin
        anchor: new google.maps.Point(0, 0) // anchor
    };

    for (var i = 0; i < markersInfos.length; i++) {
        var markerInfos = markersInfos[i]
        markerIcon["url"] = markerInfos.url
        var myLatLng = new google.maps.LatLng(markerInfos.Position),
            marker = new google.maps.Marker({
                position: myLatLng,
                title: markerInfos.name,
                map: map,
                icon: markerIcon
            });
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                //map.panTo(locations[i][1]);
                displayImage(markersInfos[i]);
            }
        })(marker, i));
        // Keep marker instances in a global array
        markers.push(marker);
    }
    if (typeof variable !== 'undefined') {
        // the variable is defined
        markerCluster.setMap(null);

    }
    if (typeof markerCluster !== 'undefined') {
        // the variable is defined
        markerCluster.clearMarkers()
        markerCluster.addMarkers(markers)
    }
}

function showVisibleMarkers() {
    var bounds = map.getBounds()
    for (var i = 0; i < markers.length; i++) {
        var marker = markers[i],
            infoPanel = $('#' + marker.title + "Div"); // array indexes start at zero, but not our class names :)

        if (bounds.contains(marker.getPosition()) === true) {
            infoPanel.show();
            masonry.recalculate(true);
        } else {
            infoPanel.hide();
            masonry.recalculate(true);
        }
    }
}

var eventDisplayer = $("#eventDisplayer");
var eventDisplayerContainer = $("#eventDisplayerContainer");
var eventDisplayerImg = $("#eventDisplayerImg");

function displayImage(marker) {
    eventDisplayer.css("display", "block");
    eventDisplayerContainer.css("display", "block");
    var img = $("#" + marker.name)
    eventDisplayerImg.attr("src", img.attr("src"));

    $("#location").text(marker.name)
    $("#rating").text(marker.rating)
    $("#caption").text(marker.text)
    $("#photographer").text(marker.Photographer)
    $('body').css('overflow', 'hidden')
}
$("#eventDisplayer").click(function() {
    eventDisplayer.css("display", "none");
    eventDisplayerContainer.css("display", "none");
    $('body').css('overflow', '')
})

/* Lock */
$("#lock, #mapHide").click(function() {
    if ($("#unlockIcon").hasClass("d-none")) {
        $("#lock").animate({
            opacity: 0.4,
            top: "10px",
            right: "10px"
        }, 1500);

        location.hash = "map";
        location.hash = null;

        $("#lockIcon").addClass("d-none")
        $("#lockInfo").addClass("d-none")
        $("#unlockIcon").removeClass("d-none")
        $("#mapHide").addClass("d-none")

        map.setOptions({ gestureHandling: 'greedy' });
    } else {
        $("#lock").animate({
            opacity: 1,
            top: "45%",
            right: "45%"
        }, 1500);

        $("#lockIcon").removeClass("d-none")
        $("#lockInfo").removeClass("d-none")
        $("#unlockIcon").addClass("d-none")
        $("#mapHide").removeClass("d-none")

        map.setOptions({ gestureHandling: 'cooperative' });
    }
});

/*

  Macy

  */
var masonry = new Macy({
    container: '#macy-container',
    trueOrder: false,
    waitForImages: false,
    useOwnImageLoader: false,
    debug: true,
    mobileFirst: true,
    columns: 1,
    margin: {
        y: 16,
        x: '2%',
    },
    breakAt: {
        2000: 3,
        1200: 3,
        940: 2,
        520: 2,
        400: 1
    },

});
/*

AOS

*/

masonry.runOnImageLoad(function() {
    masonry.recalculate(true);
    AOS.init();
}, true);

function debounce(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this,
            args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};
$(window).on('resize', debounce(function() {
    AOS.init();
}, 500));


$(document).ready(function() {
    console.log("ready!");

    $("#filterShow").click(function() {
        $("#filter").slideToggle("slow")
        $("#filterShow").hide()
    })
    $("#filterHide").click(function() {
        $("#filter").slideToggle("slow")
        $("#filterShow").show()
    })


    $(".filter").click(function() {

        // Verify the state of the filters
        // if all active and one is selected, disable others.
        // if only one is activate and it is disabled. Activate all.

        var filtersNb = $(".filter.active").length
        var categories = []
        var thisFilter = this

        $(".filter.active").each(function() { categories.push(this.id) });

        switch (filtersNb) {
            case 1:
                var activeFilter = $(".filter.active")
                if (this.id == activeFilter[0].id)
                    $(".filter").each(function(index) {
                        if (this.id != activeFilter.id) {
                            $(this).addClass("active");
                            categories.push(this.id)
                        }
                    });
                else
                    $(this).addClass("active")
                categories.push(this.id)
                    // code block
                break;
            case 3:
                $(".filter").each(function(index) {
                    if (thisFilter.id != this.id) {
                        $(this).removeClass("active");
                        categories.splice(categories.indexOf(this.id), 1);
                    }
                });
                // code block
                break;
            default:
                $(this).toggleClass("active")
                if ($(this).hasClass("active")) categories.push(this.id)
                else categories.splice(categories.indexOf(this.id), 1);
                // code block
        }
        var markerTemp = []
        markersInfos.forEach((item, index) => {
            if (categories.indexOf(item.eventType) >= 0)
                markerTemp.push(item)
        });
        addMarkers(markerTemp)
    })
});